
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

// Currency class for conversion logic
class Currency {
    private String code;
    private String name;
    private double exchangeRate;

    public Currency(String code, String name, double exchangeRate) {
        this.code = code;
        this.name = name;
        this.exchangeRate = exchangeRate;
    }

    public String getCode() {
        return code;
    }

    public double getExchangeRate() {
        return exchangeRate;
    }

    public double convertTo(double amount, Currency targetCurrency) {
        return (amount * targetCurrency.getExchangeRate()) / this.exchangeRate;
    }
}

// Main Application with Login
public class CurrencyConverterApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(LoginPage::new);
    }
}

//Login Page
class LoginPage extends JFrame {
 private JTextField usernameField;
 private JPasswordField passwordField;
 private JButton loginButton, signUpButton, forgotPasswordButton;

 // Simulated database of user credentials
 private static final Map<String, String> userCredentials = new HashMap<>();

 static {
     // Default user credentials
     userCredentials.put("Simi Mathew", "simi");
 }

 public LoginPage() {
     setTitle("Login");
     setSize(400, 300);
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     setLayout(new GridLayout(4, 2, 10, 10));

     // Components
     JLabel usernameLabel = new JLabel("Username:");
     usernameField = new JTextField();

     JLabel passwordLabel = new JLabel("Password:");
     passwordField = new JPasswordField();

     loginButton = new JButton("Login");
     signUpButton = new JButton("Sign Up");
     forgotPasswordButton = new JButton("Forgot Password");

     // Add components to frame
     add(usernameLabel);
     add(usernameField);
     add(passwordLabel);
     add(passwordField);
     add(loginButton);
     add(signUpButton);
     add(new JLabel()); // Empty space for alignment
     add(forgotPasswordButton);

     // Action listeners
     loginButton.addActionListener(new LoginButtonListener());
     signUpButton.addActionListener(new SignUpButtonListener());
     forgotPasswordButton.addActionListener(new ForgotPasswordButtonListener());

     setVisible(true);
 }

 // Login button action
 private class LoginButtonListener implements ActionListener {
     @Override
     public void actionPerformed(ActionEvent e) {
         String username = usernameField.getText();
         String password = new String(passwordField.getPassword());

         // Check if the credentials are valid
         if (userCredentials.containsKey(username) && userCredentials.get(username).equals(password)) {
             JOptionPane.showMessageDialog(null, "Login Successful!");
             dispose(); // Close login page
             SwingUtilities.invokeLater(CurrencyConverter::new); // Open converter page
         } else {
             JOptionPane.showMessageDialog(null, "Invalid Username or Password. Try again.");
         }
     }
 }

 // Sign-Up button action
 private class SignUpButtonListener implements ActionListener {
     @Override
     public void actionPerformed(ActionEvent e) {
         new SignUpPage();
     }
 }

 // Forgot Password button action
 private class ForgotPasswordButtonListener implements ActionListener {
     @Override
     public void actionPerformed(ActionEvent e) {
         new ForgotPasswordPage();
     }
 }
}

// Currency Converter Page
class CurrencyConverter extends JFrame {
    private JComboBox<String> fromCurrencyCombo, toCurrencyCombo;
    private JTextField amountField;
    private JLabel resultLabel;
    private JButton convertButton, payButton, cancelButton;

    private final Currency usd = new Currency("USD", "United States Dollar", 1.0);
    private final Currency eur = new Currency("EUR", "Euro", 0.85);
    private final Currency gbp = new Currency("GBP", "British Pound", 0.75);
    private final Currency inr = new Currency("INR", "Indian Rupee", 75.0);

    public CurrencyConverter() {
        setTitle("Currency Converter & Payment");
        setSize(400, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(7, 2, 10, 10));

        String[] currencies = {"USD", "EUR", "GBP", "INR"};

        JLabel fromLabel = new JLabel("From Currency:");
        fromCurrencyCombo = new JComboBox<>(currencies);

        JLabel toLabel = new JLabel("To Currency:");
        toCurrencyCombo = new JComboBox<>(currencies);

        JLabel amountLabel = new JLabel("Enter Amount:");
        amountField = new JTextField();

        convertButton = new JButton("Convert");
        resultLabel = new JLabel("Converted Amount: ");

        payButton = new JButton("Pay");
        cancelButton = new JButton("Cancel");

        add(fromLabel);
        add(fromCurrencyCombo);
        add(toLabel);
        add(toCurrencyCombo);
        add(amountLabel);
        add(amountField);
        add(convertButton);
        add(resultLabel);
        add(payButton);
        add(cancelButton);

        convertButton.addActionListener(new ConvertButtonListener());
        payButton.addActionListener(e -> JOptionPane.showMessageDialog(null, "Payment Successful!"));
        cancelButton.addActionListener(e -> JOptionPane.showMessageDialog(null, "Transaction Canceled."));

        setVisible(true);
    }

    private class ConvertButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                String fromCurrencyCode = (String) fromCurrencyCombo.getSelectedItem();
                String toCurrencyCode = (String) toCurrencyCombo.getSelectedItem();
                double amount = Double.parseDouble(amountField.getText());

                Currency fromCurrency = getCurrency(fromCurrencyCode);
                Currency toCurrency = getCurrency(toCurrencyCode);

                double convertedAmount = fromCurrency.convertTo(amount, toCurrency);
                resultLabel.setText("Converted Amount: " + String.format("%.2f", convertedAmount) + " " + toCurrencyCode);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Please enter a valid amount.");
            }
        }

        private Currency getCurrency(String code) {
            switch (code) {
                case "USD":
                    return usd;
                case "EUR":
                    return eur;
                case "GBP":
                    return gbp;
                case "INR":
                    return inr;
                default:
                    return usd; // Default to USD
            }
        }
    }
}
